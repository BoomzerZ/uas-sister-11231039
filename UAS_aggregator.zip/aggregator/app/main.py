from fastapi import FastAPI
from .api import router
import asyncio
from .worker import start_workers

app = FastAPI(title="Distributed Log Aggregator")

app.include_router(router)

@app.on_event("startup")
async def startup():
    asyncio.create_task(start_workers())
