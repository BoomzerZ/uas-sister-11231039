import asyncio
import os
import json
import redis.asyncio as redis
from .db import get_pool

BROKER_URL = os.getenv("BROKER_URL")
WORKER_COUNT = int(os.getenv("WORKER_COUNT", 2))

async def worker(name: str):
    r = redis.from_url(BROKER_URL)
    pool = await get_pool()

    while True:
        _, raw = await r.blpop("event_queue")
        event = json.loads(raw)

        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    INSERT INTO processed_events
                    (topic, event_id, timestamp, source, payload)
                    VALUES ($1, $2, $3, $4, $5)
                    ON CONFLICT DO NOTHING
                    RETURNING event_id
                    """,
                    event["topic"],
                    event["event_id"],
                    event["timestamp"],
                    event["source"],
                    event["payload"]
                )
                # no side effect duplication possible

async def start_workers():
    await asyncio.gather(
        *[worker(f"W{i}") for i in range(WORKER_COUNT)]
    )
