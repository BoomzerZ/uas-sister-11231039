from fastapi import APIRouter, HTTPException
from typing import List, Union
from .schemas import Event
from .db import get_pool

router = APIRouter()

@router.post("/publish")
async def publish(events: Union[Event, List[Event]]):
    if isinstance(events, Event):
        events = [events]

    pool = await get_pool()
    results = []

    async with pool.acquire() as conn:
        async with conn.transaction():  # READ COMMITTED (default)
            for ev in events:
                await conn.execute(
                    "UPDATE stats SET received = received + 1 WHERE id = 1"
                )

                row = await conn.fetchrow(
                    """
                    INSERT INTO processed_events
                    (topic, event_id, timestamp, source, payload)
                    VALUES ($1, $2, $3, $4, $5)
                    ON CONFLICT DO NOTHING
                    RETURNING event_id
                    """,
                    ev.topic,
                    ev.event_id,
                    ev.timestamp,
                    ev.source,
                    ev.payload
                )

                if row:
                    await conn.execute(
                        "UPDATE stats SET unique_processed = unique_processed + 1 WHERE id = 1"
                    )
                    results.append({"event_id": ev.event_id, "status": "processed"})
                else:
                    await conn.execute(
                        "UPDATE stats SET duplicate_dropped = duplicate_dropped + 1 WHERE id = 1"
                    )
                    results.append({"event_id": ev.event_id, "status": "duplicate"})

    return results


@router.get("/events")
async def get_events(topic: str):
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT topic, event_id, timestamp, source, payload FROM processed_events WHERE topic=$1",
            topic
        )
    return [dict(r) for r in rows]


@router.get("/stats")
async def stats():
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT * FROM stats WHERE id = 1")
    return dict(row)
